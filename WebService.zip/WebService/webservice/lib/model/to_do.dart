// lib/model/to_do.dart

class ToDo {
  ToDo({
    this.id,
    this.title,
    this.completed,
  });

  int? id;
  String? title;
  bool? completed;

  factory ToDo.fromJson(Map<String, dynamic> json) => ToDo(
    id: json["id"],
    title: json["title"],
    completed: json["completed"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "completed": completed,
  };
}
