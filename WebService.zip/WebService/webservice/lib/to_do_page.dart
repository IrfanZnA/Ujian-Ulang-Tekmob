import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:<webservice>/model/to_do.dart';

class ToDoPage extends StatefulWidget {
  const ToDoPage({super.key});

  @override
  _ToDoPageState createState() => _ToDoPageState();
}

class _ToDoPageState extends State<ToDoPage> {
  List<ToDo>? toDoList;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchToDoList();
  }

  Future<void> fetchToDoList() async {
    setState(() {
      isLoading = true;
    });

    final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/todos'));

    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      setState(() {
        toDoList = jsonResponse.map((toDo) => ToDo.fromJson(toDo)).toList();
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      throw Exception('Failed to load To Do');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To Do List'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : toDoList == null
              ? Center(child: Text('No data available'))
              : ListView.builder(
                  itemCount: toDoList!.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(toDoList![index].title ?? 'No Title'),
                      trailing: Icon(
                        toDoList![index].completed! ? Icons.check_box : Icons.check_box_outline_blank,
                        color: toDoList![index].completed! ? Colors.green : null,
                      ),
                    );
                  },
                ),
    );
  }
}
