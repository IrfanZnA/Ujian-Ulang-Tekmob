import 'package:flutter/material.dart';
import 'package:<webservice>/model/lto_do_page.dart'; 
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ToDoPage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  Mobil? mobil;
  bool isLoading = false;

  Future<void> fetchMobil() async {
    setState(() {
      isLoading = true;
    });

    final response = await http.get(Uri.parse('https://api.example.com/mobil/1'));

    if (response.statusCode == 200) {
      setState(() {
        mobil = mobilFromJson(response.body);
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      throw Exception('Failed to load mobil');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchMobil();
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? CircularProgressIndicator()
        : mobil == null
            ? Text('No data')
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('ID: ${mobil!.id}'),
                  Text('Brand: ${mobil!.brand}'),
                  Text('Model: ${mobil!.model}'),
                  Text('Color: ${mobil!.color}'),
                ],
              );
  }
}

Mobil mobilFromJson(String str) => Mobil.fromJson(json.decode(str));
String mobilToJson(Mobil data) => json.encode(data.toJson());

class Mobil {
  Mobil({
    this.id,
    this.brand,
    this.model,
    this.color,
  });

  int? id;
  String? brand;
  String? model;
  String? color;

  factory Mobil.fromJson(Map<String, dynamic> json) => Mobil(
    id: json["id"],
    brand: json["brand"],
    model: json["model"],
    color: json["color"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "brand": brand,
    "model": model,
    "color": color,
  };
}
